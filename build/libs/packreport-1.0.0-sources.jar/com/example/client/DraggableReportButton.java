
package com.example.client;

import java.util.function.BiConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public class DraggableReportButton extends class_339 {    
    
    public boolean isDragging() {
    return this.dragging;
    }

    public void moveTo(
            double mouseX,
            double mouseY,
            int screenWidth,
            int screenHeight
    ) {
        if (!this.dragging) {
            return;
        }

        int newX = (int) (mouseX - this.dragOffsetX);
        int newY = (int) (mouseY - this.dragOffsetY);

        newX = Math.max(0, Math.min(
                newX, Math.max(0, screenWidth - this.field_22758)
        ));

        newY = Math.max(0, Math.min(
                newY, Math.max(0, screenHeight - this.field_22759)
        ));

        this.method_48229(newX, newY);
        this.onMove.accept(newX, newY);
    }

    
    public void beginDrag(double mouseX, double mouseY) {
        this.dragging = true;
        this.dragOffsetX = mouseX - this.method_46426();
        this.dragOffsetY = mouseY - this.method_46427();
    }

    public void endDrag() {
        this.dragging = false;
    }

    private final Runnable onCopy;
    private final BiConsumer<Integer, Integer> onMove;

    private boolean dragging = false;
    private double dragOffsetX;
    private double dragOffsetY;

    public DraggableReportButton(
            int x,
            int y,
            int width,
            int height,
            class_2561 message,
            Runnable onCopy,
            BiConsumer<Integer, Integer> onMove
    ) {
        super(x, y, width, height, message);
        this.onCopy = onCopy;
        this.onMove = onMove;
    }

    @Override
    protected void method_48579(
            class_332 graphics,
            int mouseX,
            int mouseY,
            float delta
    ) {
        int background = this.method_25367()
                ? 0xFF454545
                : 0xFF202020;

        graphics.method_25294(
                this.method_46426(),
                this.method_46427(),
                this.method_46426() + this.field_22758,
                this.method_46427() + this.field_22759,
                background
        );

        graphics.method_27534(
                class_310.method_1551().field_1772,
                this.method_25369(),
                this.method_46426() + this.field_22758 / 2,
                this.method_46427() + (this.field_22759 - 8) / 2,
                0xFFFFFFFF
        );
    }

    @Override
    public boolean method_25402(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (!this.field_22763 || !this.field_22764
                || !this.method_25405(mouseX, mouseY)) {
            return false;
        }

        if (button == 0) {
            this.onCopy.run();
            return true;
        }

        if (button == 1) {
            this.dragging = true;
            this.dragOffsetX = mouseX - this.method_46426();
            this.dragOffsetY = mouseY - this.method_46427();
            this.method_25365(true);
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25403(
            double mouseX,
            double mouseY,
            int button,
            double dragX,
            double dragY
    ) {
        if (!this.dragging || button != 1) {
            return false;
        }

        class_310 minecraft = class_310.method_1551();

        int screenWidth =
                minecraft.method_22683().method_4486();
        int screenHeight =
                minecraft.method_22683().method_4502();

        int newX = (int) (mouseX - this.dragOffsetX);
        int newY = (int) (mouseY - this.dragOffsetY);

        newX = Math.max(0, Math.min(
                newX, Math.max(0, screenWidth - this.field_22758)
        ));

        newY = Math.max(0, Math.min(
                newY, Math.max(0, screenHeight - this.field_22759)
        ));

        this.method_48229(newX, newY);
        this.onMove.accept(newX, newY);

        return true;
    }

    @Override
    public boolean method_25406(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button == 1 && this.dragging) {
            this.dragging = false;
            return true;
        }

        return false;
    }

    @Override
    protected void method_47399(
            class_6382 narrationElementOutput
    ) {
        this.method_37021(narrationElementOutput);
    }
}
