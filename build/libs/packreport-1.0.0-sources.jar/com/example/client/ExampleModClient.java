
package com.example.client;

import com.example.ExampleMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_370;
import net.minecraft.class_370.class_371;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_442;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class ExampleModClient implements ClientModInitializer {
    
    private static void copyReport(
            net.minecraft.class_310 client
    ) {
        String report = ExampleMod.goonscript;

        if (report == null || report.isBlank()) {
            class_370.method_27024(
                    client.method_1566(),
                    class_371.field_36445,
                    class_2561.method_43470("PackReport"),
                    class_2561.method_43470("Report is empty!")
            );
            return;
        }

        client.field_1774.method_1455(report);

        class_370.method_27024(
                client.method_1566(),
                class_371.field_36445,
                class_2561.method_43470("PackReport"),
                class_2561.method_43470("Report copied!")
        );
    }

    private static final Path CONFIG_FILE =
            FabricLoader.getInstance()
                    .getConfigDir()
                    .resolve("packreport.properties");

    private static final int BUTTON_WIDTH = 280;
    private static final int BUTTON_HEIGHT = 24;

    private static int buttonX = 10;
    private static int buttonY = 10;

    @Override
    public void onInitializeClient() {
        loadPosition();

        ScreenEvents.AFTER_INIT.register(
                (client, screen, scaledWidth, scaledHeight) -> {

                    // Main menu: fixed button at the bottom centre.
                    if (screen instanceof class_442) {
                        int width = 220;
                        int height = 20;
                        int x = (scaledWidth - width) / 2;
                        int y = scaledHeight - 40;

                        class_4185 mainMenuButton = class_4185.method_46430(
                                class_2561.method_43470("Copy PackReport"),
                                button -> copyReport(client)
                        ).method_46434(x, y, width, height).method_46431();

                        Screens.getButtons(screen).add(mainMenuButton);
                    }

                    // Pause menu: draggable button with saved position.
                    if (screen instanceof class_433) {
                        buttonX = Math.max(
                                0,
                                Math.min(
                                        buttonX,
                                        Math.max(0, scaledWidth - BUTTON_WIDTH)
                                )
                        );

                        buttonY = Math.max(
                                0,
                                Math.min(
                                        buttonY,
                                        Math.max(0, scaledHeight - BUTTON_HEIGHT)
                                )
                        );

                        DraggableReportButton copyButton =
                                new DraggableReportButton(
                                        buttonX,
                                        buttonY,
                                        BUTTON_WIDTH,
                                        BUTTON_HEIGHT,
                                        class_2561.method_43470(
                                                "Copy PackReport · Right-click to move"
                                        ),
                                        () -> copyReport(client),
                                        (x, y) -> {
                                            buttonX = x;
                                            buttonY = y;
                                        }
                                );

                        Screens.getButtons(screen).add(copyButton);

                        ScreenEvents.afterRender(screen).register(
                                (s, graphics, mouseX, mouseY, tickDelta) -> {
                                    copyButton.moveTo(
                                            mouseX,
                                            mouseY,
                                            s.field_22789,
                                            s.field_22790
                                    );
                                }
                        );

                        ScreenMouseEvents.beforeMouseClick(screen).register(
                                (s, mouseX, mouseY, button) -> {
                                    if (button == 1
                                            && mouseX >= copyButton.method_46426()
                                            && mouseX <= copyButton.method_46426()
                                                    + copyButton.method_25368()
                                            && mouseY >= copyButton.method_46427()
                                            && mouseY <= copyButton.method_46427()
                                                    + copyButton.method_25364()) {

                                        copyButton.beginDrag(mouseX, mouseY);
                                    }
                                }
                        );

                        ScreenMouseEvents.beforeMouseRelease(screen).register(
                                (s, mouseX, mouseY, button) -> {
                                    if (button == 1) {
                                        copyButton.endDrag();
                                        savePosition();
                                    }
                                }
                        );
                    }
                }
        );
    }

    private static void loadPosition() {
        if (!Files.exists(CONFIG_FILE)) {
            return;
        }

        Properties properties = new Properties();

        try (InputStream input = Files.newInputStream(CONFIG_FILE)) {
            properties.load(input);

            buttonX = Integer.parseInt(
                    properties.getProperty("x", "10")
            );
            buttonY = Integer.parseInt(
                    properties.getProperty("y", "10")
            );

            System.out.println("PackReport: button position loaded.");
        } catch (IOException | NumberFormatException e) {
            System.err.println(
                    "PackReport: couldn't load button position: "
                            + e.getMessage()
            );
        }
    }

    private static void savePosition() {
        Properties properties = new Properties();

        properties.setProperty("x", Integer.toString(buttonX));
        properties.setProperty("y", Integer.toString(buttonY));

        try {
            Files.createDirectories(CONFIG_FILE.getParent());

            try (OutputStream output =
                         Files.newOutputStream(CONFIG_FILE)) {
                properties.store(output, "PackReport button position");
            }

            System.out.println("PackReport: button position saved.");
        } catch (IOException e) {
            System.err.println(
                    "PackReport: couldn't save button position: "
                            + e.getMessage()
            );
        }
    }
}
